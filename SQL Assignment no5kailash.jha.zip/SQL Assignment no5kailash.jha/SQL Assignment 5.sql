USE [master]
GO
/****** Object:  Database [UserProductRelation]    Script Date: 9/7/2023 11:24:37 AM ******/
CREATE DATABASE [UserProductRelation]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'UserProductRelation', FILENAME = N'C:\Users\kailash.jha\UserProductRelation.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'UserProductRelation_log', FILENAME = N'C:\Users\kailash.jha\UserProductRelation_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [UserProductRelation] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [UserProductRelation].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [UserProductRelation] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [UserProductRelation] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [UserProductRelation] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [UserProductRelation] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [UserProductRelation] SET ARITHABORT OFF 
GO
ALTER DATABASE [UserProductRelation] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [UserProductRelation] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [UserProductRelation] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [UserProductRelation] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [UserProductRelation] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [UserProductRelation] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [UserProductRelation] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [UserProductRelation] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [UserProductRelation] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [UserProductRelation] SET  DISABLE_BROKER 
GO
ALTER DATABASE [UserProductRelation] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [UserProductRelation] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [UserProductRelation] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [UserProductRelation] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [UserProductRelation] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [UserProductRelation] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [UserProductRelation] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [UserProductRelation] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [UserProductRelation] SET  MULTI_USER 
GO
ALTER DATABASE [UserProductRelation] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [UserProductRelation] SET DB_CHAINING OFF 
GO
ALTER DATABASE [UserProductRelation] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [UserProductRelation] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [UserProductRelation] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [UserProductRelation] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [UserProductRelation] SET QUERY_STORE = OFF
GO
USE [UserProductRelation]
GO
/****** Object:  UserDefinedFunction [dbo].[TotalBill]    Script Date: 9/7/2023 11:24:37 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[TotalBill]
(
 @TotalPrice  DECIMAL(18,2),
 @DiscountInPerc INT
)
RETURNS DECIMAL(18,2)
AS
BEGIN
		RETURN @TotalPrice - (@TotalPrice * @DiscountInPerc/100)
END
GO
/****** Object:  Table [dbo].[Product]    Script Date: 9/7/2023 11:24:37 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Product](
	[ProductId] [int] NOT NULL,
	[ProductName] [varchar](50) NOT NULL,
	[ProductQuantity] [varchar](50) NOT NULL,
	[Price] [decimal](18, 2) NULL,
	[UserId] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserDetails]    Script Date: 9/7/2023 11:24:37 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserDetails](
	[UserId] [int] NOT NULL,
	[UserName] [varchar](50) NOT NULL,
	[City] [varchar](50) NOT NULL,
	[ContactNumber] [varchar](50) NOT NULL,
	[Payment] [decimal](18, 2) NULL,
	[DateofJoining] [varchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Product]  WITH CHECK ADD FOREIGN KEY([UserId])
REFERENCES [dbo].[UserDetails] ([UserId])
GO
/****** Object:  StoredProcedure [dbo].[GetUserProductDetails]    Script Date: 9/7/2023 11:24:37 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[GetUserProductDetails]
@Case INT,
@discount INT
AS
BEGIN
	IF @Case=1
		BEGIN
			SELECT		UR.UserId,
						UR.UserName,
						UR.City,
						PT.ProductId,
						UR.ProductPrice,
						UR.ProductQuantity
			FROM		Users UR
			INNER JOIN	Product PT
			ON		UR.UserId=PT.UserId
	END

	IF @Case=2
		BEGIN
			SELECT	  UR.UserId,
					  UR.Username,
					  UR.PurchasedProduct AS ProductName,
					  PT.ProductId,
					  UR.ProductPrice  AS TotalPrice,
					  [dbo].TotalBill(PT.ProductPrice,@discount) AS FinalAmount,
					  UR.ProductQuantity
			FROM	  Users UR
			INNER JOIN Product PT
			ON		 UR.UserId=PT.UserId
		END 
END
GO
/****** Object:  StoredProcedure [dbo].[UserProduct]    Script Date: 9/7/2023 11:24:37 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[UserProduct]
@Case INT,
@Discount INT,
@userId	  INT=0
AS
BEGIN
	IF @Case=1
		BEGIN
			SELECT		US.UserId,
						US.UserName,
						PT.ProductName,
						PT.Price,
						PT.ProductQuantity
			FROM		UserDetails US
			INNER JOIN	Product PT
			ON		US.UserId=PT.UserId
	END

	IF @Case=2
		BEGIN
			SELECT	  US.UserId,
					  US.UserName,
					  PT.ProductName AS ProductName,
					  PT.Price  AS TotalPrice,
					  [dbo].TotalBill(PT.Price,@Discount) AS FinalPrice,
					  PT.ProductQuantity
			FROM	  UserDetails US
			INNER JOIN Product PT
			ON		 US.UserId=PT.UserId
			WHERE	 US.UserId=@userId

		END 
END
GO
USE [master]
GO
ALTER DATABASE [UserProductRelation] SET  READ_WRITE 
GO
