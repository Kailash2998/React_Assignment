DROP TABLE IF EXISTS Student,Teacher,Department
					
--//Department Table

CREATE TABLE Department
(
	DepartmentId	INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
    DepartmentName	VARCHAR(50) NOT NULL,
	City	VARCHAR(50)  NOT NULL,
	HOD	VARCHAR(50)  NOT NULL,  
	ContactNumber	VARCHAR(50)  NOT NULL
	
 );


 INSERT INTO Department ( DepartmentName,City,HOD,ContactNumber)VALUES ('Chemical engineering', 'Nashik', 'Rajesh Pawar', '+919833653245'),
																	   ('Civil engineering','Nashik','Pravin Fekle','+919925367284'),
																	   ('Computer Science','Nashik','JayShree Bhangre','+918298163523'),
																	   ('Electrical engineering','Nashik','Suresh Tambe','+916208536950'),
																	   ('Mechanical engineering','Nashik','Sangita Gadakh','+919850065452')


 
 SELECT		DepartmentId,
			DepartmentName,
			City,
			HOD,
			ContactNumber
FROM		Department

--//Teacher Table


CREATE TABLE Teacher
(
	TeacherId	INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
    TeacherName	VARCHAR(50) NOT NULL,
	City	VARCHAR(50)  NOT NULL,
	Specialization	VARCHAR(50)  NOT NULL, 
	Age	INT	 NOT NULL, 
	ContactNumber	VARCHAR(50)  NOT NULL,
	Salary	VARCHAR(50)  NOT NULL,
	DepartmentId	INT	FOREIGN KEY REFERENCES Department(DepartmentId)  
	
 );

 INSERT INTO Teacher ( TeacherName,City,Specialization,Age,ContactNumber,Salary,DepartmentId)
														VALUES ('Rajesh Pawar','Nashik','Chemical engineering',56,'+919833653245','76000',1),
															   ('Pravin Fekle ','Nashik','Civil engineering',62,'+919925367284','100000',2),
															   ('JayShree Bhangre ','Nashik','Computer Science',45,'+918298163523','94000',3),
															   ('Suresh Tambe ','Nashik','Electrical engineering',65,'+916208536950','80000',4),
															   ('Sangita Gadakh ','Nashik','Mechanical engineering',59,'+919850065452','70200',5)
					
					

SELECT  TeacherId,
		TeacherName,
		City,
		Specialization,
		Age,
		ContactNumber,
		Salary,
		DepartmentId
FROM	Teacher

					

--//Student Table

		

CREATE TABLE Student
(
	StudentId	INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
    StudentName	VARCHAR(50) NOT NULL,
	City	VARCHAR(50)  NOT NULL,
	Gender	VARCHAR(10) NOT NULL, 
	Age	INT	 NOT NULL, 
	CGPA	Float	 NOT NULL, 
	ContactNumber	VARCHAR(50)  NOT NULL,
	Fees	VARCHAR(50)  NOT NULL,
	DepartmentId	INT	FOREIGN KEY REFERENCES Department(DepartmentId)  
		
 );

 INSERT INTO Student (StudentName,City,Gender,Age,CGPA,ContactNumber,Fees,DepartmentId)VALUES ('Deepak Khule','Nashik','Male',22,9.78,'+917849825644','40000',1),
																						 ('Pooja Sonowane','Nashik','Female',22,9.88,'+919965238542','45000',2),
																						 ('Subhangi Pawar','Nashik','Female',21,9.92,'+916207425631','95000',3),
																						 ('Suraj Golesar','Nashik','Male',22,9.82,'+917544053965','65000',4),
																						 ('Vijay Satpute','Nashik','Male',21,9.86,'+918082120515','44200',5)
SELECT  StudentId,
		StudentName,
		City,
		Gender,
		CGPA,
		ContactNumber,
		Fees,
		DepartmentId
FROM	Student




-----------------------------SQL PRE-DEFINE FUNCTIONS


DECLARE @String VARCHAR(50) = 'water is more precious than gold'

--1) CHARINDEX
SELECT CHARINDEX('water', @String, 1) AS MatchPosition

--2) CONCAT
SELECT CONCAT('UJJWALA', 'GAS', 'YOGNA')

--3) LEFT
SELECT LEFT('water is more precious than gold',4) AS ExtractString

--4) LEN
SELECT LEN('water is more precious than gold')

--5) LOWER
SELECT LOWER('water is more precious than gold')

--6) REPLACE
SELECT REPLACE('water is more precious ','precious','than gold')

--7) REVERSE
SELECT REVERSE('water is more precious than gold')

--8) UPPER
SELECT UPPER('water is more precious than gold')

--9) REPLICATE
SELECT REPLICATE('Save Our Planet - ',3)

--10) TRIM
SELECT TRIM('   water is more precious than gold    ')


----------------SQL KEYWORDS

--1) IS NOT NULL
SELECT          StudentId, 
				StudentName, 
				City, 
				Gender, 
				CGPA, 
				Age,
				DepartmentId
FROM			Student
WHERE   Age IS NOT NULL


--2) BETWEEN
SELECT		StudentName, 
			Age 
FROM		Student
WHERE   Age BETWEEN 18 AND 23


--3) CASE
SELECT   StudentName,
		 Age,
CASE   WHEN Age >= 18 
    THEN 'Congratulations you are eligible for voting'
    ELSE 'Sorry, You are not eligible'
END    AS VotingStatus
FROM   Student


--4) ASC
SELECT   StudentName
FROM	 Student
ORDER BY  StudentName ASC


--5)  DESC
SELECT		StudentName
FROM		Student
ORDER BY  StudentName DESC

--6) FROM
SELECT		StudentName,
			CGPA
FROM		Student
WHERE   CGPA=9.92

--7) IN
SELECT          TeacherId, 
				TeacherName, 
				Specialization, 
				Age,
				DepartmentId
FROM   Teacher
WHERE   Specialization IN ('Chemical engineering','Computer Science')



--8)  NOT IN
SELECT          TeacherId, 
				TeacherName, 
				Specialization, 
				Salary, 
				Age,
				DepartmentId
FROM			Teacher
WHERE   Specialization NOT IN ('Electrical engineering','Civil engineering')


--9) OR
SELECT          StudentId, 
				StudentName,  
				Fees, 
				Age,
				DepartmentId
FROM			Student
WHERE   Fees=35000 OR Fees < 65000


--10) ALL
SELECT  StudentName,
		Fees
FROM	Student
WHERE  Fees = ALL (SELECT Fees FROM Student WHERE Fees = 30000)

