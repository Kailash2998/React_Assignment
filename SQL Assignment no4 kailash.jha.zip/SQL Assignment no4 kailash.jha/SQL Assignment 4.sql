DROP TABLE IF EXISTS Student,Teacher,Department
					
--//Department Table

CREATE TABLE Department
(
	DepartmentId	INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
    DepartmentName	VARCHAR(50) NOT NULL,
	City	VARCHAR(50)  NOT NULL,
	HOD	VARCHAR(50)  NOT NULL,  
	ContactNumber	VARCHAR(50)  NOT NULL
	
 );


 INSERT INTO Department ( DepartmentName,City,HOD,ContactNumber)VALUES ('Chemical engineering', 'Nashik', 'Rajesh Pawar', '+919833653245'),
																	   ('Civil engineering','Nashik','Pravin Fekle','+919925367284'),
																	   ('Computer Science','Nashik','JayShree Bhangre','+918298163523'),
																	   ('Electrical engineering','Nashik','Suresh Tambe','+916208536950'),
																	   ('Mechanical engineering','Nashik','Sangita Gadakh','+919850065452')


 
 SELECT		DepartmentId,
			DepartmentName,
			City,
			HOD,
			ContactNumber
FROM		Department

--//Teacher Table


CREATE TABLE Teacher
(
	TeacherId	INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
    TeacherName	VARCHAR(50) NOT NULL,
	City	VARCHAR(50)  NOT NULL,
	Specialization	VARCHAR(50)  NOT NULL, 
	Age	INT	 NOT NULL, 
	ContactNumber	VARCHAR(50)  NOT NULL,
	Salary	VARCHAR(50)  NOT NULL,
	DepartmentId	INT	FOREIGN KEY REFERENCES Department(DepartmentId)  
	
 );

 INSERT INTO Teacher ( TeacherName,City,Specialization,Age,ContactNumber,Salary,DepartmentId)
														VALUES ('Rajesh Pawar','Nashik','Chemical engineering',56,'+919833653245','76000',1),
															   ('Pravin Fekle ','Nashik','Civil engineering',62,'+919925367284','100000',2),
															   ('JayShree Bhangre ','Pune','Computer Science',45,'+918298163523','94000',3),
															   ('Suresh Tambe ','Pune','Electrical engineering',65,'+916208536950','80000',4),
															   ('Sangita Gadakh ','Mumbai','Mechanical engineering',59,'+919850065452','70200',5)
					
					

SELECT  TeacherId,
		TeacherName,
		City,
		Specialization,
		Age,
		ContactNumber,
		Salary,
		DepartmentId
FROM	Teacher

					

--//Student Table

		
		

CREATE TABLE Student
(
	StudentId	INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
    StudentName	VARCHAR(50) NOT NULL,
	City	VARCHAR(50)  NOT NULL,
	Gender	VARCHAR(10) NOT NULL, 
	Age	INT	 NOT NULL, 
	CGPA	Float	 NOT NULL, 
	ContactNumber	VARCHAR(50)  NOT NULL,
	Fees	VARCHAR(50)  NOT NULL,
	DepartmentId	INT	FOREIGN KEY REFERENCES Department(DepartmentId)  
		
 );

 INSERT INTO Student (StudentName,City,Gender,Age,CGPA,ContactNumber,Fees,DepartmentId)VALUES ('Deepak Khule','Nashik','Male',22,9.88,'+917849825644','40000',1),
																							  ('Pooja Sonowane','Nashik','Female',22,9.88,'+919965238542','45000',2),
																							  ('Subhangi Pawar','Pune','Female',21,9.92,'+916207425631','95000',3),
																							  ('Suraj Golesar','Pune','Male',22,9.92,'+917544053965','65000',4),
																							  ('Vijay Satpute','Mumbai','Male',21,9.86,'+918082120515','44200',5)
																							  
SELECT  StudentId,
		StudentName,
		City,
		Gender,
		CGPA,
		ContactNumber,
		Fees,
		DepartmentId
FROM	Student

--------------------------//Using Group By
---1)COUNT
SELECT	City,
COUNT	(Fees)
AS		FeesSUM
FROM	Student
GROUP BY	City


---2)AVG
SELECT	City,
AVG		(CGPA)
AS		CGPASUM
FROM	Student
GROUP BY	City

---3)SUM
SELECT	City,
SUM		(CGPA)
AS		CGPASUM
FROM	Student
GROUP BY	City

---4)MAX
SELECT	Specialization,
MAX		(Salary)
AS		FeesSUM
FROM	Teacher
GROUP BY	Specialization

---5)MIN
SELECT	City,
MIN		(Salary)
AS		SalarySUM
FROM	Teacher
GROUP BY	City

--------------------------//Using Having
---1)MIN
SELECT	City,
MIN		(Salary)
AS		SalarySUM
FROM	Teacher
GROUP BY	City
HAVING City IN ('PUNE')

---2)MAX
SELECT	Specialization,
MAX		(Salary)
AS		SalarySUM
FROM	Teacher
GROUP BY	Specialization
HAVING  MAX (Salary) < 80000	

---3)SUM
SELECT	City,
SUM		(CGPA)
AS		CGPASUM
FROM	Student
GROUP BY	City
HAVING  SUM (CGPA) BETWEEN 9.86 AND 9.91

---4)AVG
SELECT	City,
AVG		(CGPA)
AS		CGPASUM
FROM	Student
GROUP BY	City
HAVING	AVG (CGPA) > 9.88 
----------------------------------------------//create Temporary table 
---------------------//1)Using #

CREATE TABLE #Library
(
  LibraryId  INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
  LibraryName  VARCHAR(50),
  BookCount  INT,
)

INSERT INTO #Library (LibraryName,BookCount)
   VALUES('National Library of India',500),
		 ('Connemara Public Library',500),
         ('Saraswathi Mahal Library',500),
		 ('State Central Library',500),
		 ('Raza Library',500)

SELECT  LibraryId,
		LibraryName,
		BookCount
FROM	#Library

----------------------//2)Using @
DECLARE @Employee AS TABLE
(
   EmployeeId  INT,
   EmplyeeName  VARCHAR(50)
)

SELECT  EmployeeId,
		EmplyeeName
FROM	@Employee

-----------------------//3)Using  SELECT
SELECT  StudentId,
		StudentName,
		Fees,
		AGE

INTO	#TEMPTABLE
FROM	Student

SELECT  StudentId,StudentName,Fees,Age
FROM	#TEMPTABLE

----------------------//4)Using CTE
;WITH CTE AS 
(
SELECT ROW_NUMBER() OVER (PARTITION BY Specialization ORDER BY Salary DESC) AS RowNumber,
  *
FROM Teacher
)

SELECT * FROM CTE WHERE RowNumber = 1;


-----Que2)// Fetch All Teachers details with Department Name using INNER JOIN for all Departments. 
 SELECT Teacher.TeacherId, 
		Teacher.TeacherName, 
		Teacher.Salary,
		Teacher.Age,
		Teacher.Specialization
		,Teacher.City,
		Teacher.ContactNumber

 FROM	Teacher 
INNER JOIN Department
ON Teacher.DepartmentId = Department.DepartmentId;


-----Que3)//Fetch Teacher and Student details of last department using LEFT JOIN.
SELECT	Student.StudentName,
		Student.Age,
		Student.CGPA,
		Teacher.TeacherName,
		Teacher.Specialization,
		Teacher.Age,
		Department.DepartmentName
FROM Teacher
  LEFT JOIN Student ON (Student.DepartmentId=Teacher.DepartmentId)
  LEFT JOIN Department ON (Department.DepartmentId=Student.DepartmentId)
  WHERE 
  Student.DepartmentId = (SELECT MAX(DepartmentId) FROM Department)AND Teacher.DepartmentId = (SELECT MAX(DepartmentId)FROM Department)
