USE [master]
GO
/****** Object:  Database [PharmacyManagment]    Script Date: 9/8/2023 12:24:14 PM ******/
CREATE DATABASE [PharmacyManagment]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'PharmacyManagment', FILENAME = N'C:\Users\kailash.jha\PharmacyManagment.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'PharmacyManagment_log', FILENAME = N'C:\Users\kailash.jha\PharmacyManagment_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [PharmacyManagment] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [PharmacyManagment].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [PharmacyManagment] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [PharmacyManagment] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [PharmacyManagment] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [PharmacyManagment] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [PharmacyManagment] SET ARITHABORT OFF 
GO
ALTER DATABASE [PharmacyManagment] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [PharmacyManagment] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [PharmacyManagment] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [PharmacyManagment] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [PharmacyManagment] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [PharmacyManagment] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [PharmacyManagment] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [PharmacyManagment] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [PharmacyManagment] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [PharmacyManagment] SET  DISABLE_BROKER 
GO
ALTER DATABASE [PharmacyManagment] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [PharmacyManagment] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [PharmacyManagment] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [PharmacyManagment] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [PharmacyManagment] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [PharmacyManagment] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [PharmacyManagment] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [PharmacyManagment] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [PharmacyManagment] SET  MULTI_USER 
GO
ALTER DATABASE [PharmacyManagment] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [PharmacyManagment] SET DB_CHAINING OFF 
GO
ALTER DATABASE [PharmacyManagment] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [PharmacyManagment] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [PharmacyManagment] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [PharmacyManagment] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [PharmacyManagment] SET QUERY_STORE = OFF
GO
USE [PharmacyManagment]
GO
/****** Object:  UserDefinedFunction [dbo].[MULTIPLICATION]    Script Date: 9/8/2023 12:24:14 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[MULTIPLICATION]
(
	@GrossAmount	DECIMAL(18,2),
	@BASICPAY		DECIMAL(18,2),
	@PF				DECIMAL(18,2),
	@PENSION		DECIMAL(18,2)
)
RETURNS DECIMAL(18,2)
AS
BEGIN
RETURN (SELECT(@GrossAmount*(@PF	+@PENSION+@BASICPAY)/100))
END
GO
/****** Object:  Table [dbo].[Employee]    Script Date: 9/8/2023 12:24:14 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Employee](
	[EmployeeId] [int] IDENTITY(1,1) NOT NULL,
	[Firstname] [varchar](50) NOT NULL,
	[Lastname] [varchar](50) NOT NULL,
	[DOB] [date] NOT NULL,
	[Role] [varchar](50) NOT NULL,
	[PharmacyId] [int] NULL,
	[DateofJoining] [date] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[EmployeeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PaymentCode]    Script Date: 9/8/2023 12:24:14 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PaymentCode](
	[PaymentCodeId] [int] IDENTITY(1,1) NOT NULL,
	[PaymentCode] [varchar](50) NOT NULL,
	[DeductionRate] [decimal](18, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[PaymentCodeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Payslip]    Script Date: 9/8/2023 12:24:14 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Payslip](
	[PayslipId] [int] IDENTITY(1,1) NOT NULL,
	[PaymentCodeId] [int] NULL,
	[EmployeeId] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[PayslipId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Pharmacy]    Script Date: 9/8/2023 12:24:14 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Pharmacy](
	[PharmacyId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](50) NOT NULL,
	[Code] [varchar](10) NOT NULL,
	[City] [varchar](50) NOT NULL,
	[CreatedDate] [varchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[PharmacyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Salary]    Script Date: 9/8/2023 12:24:14 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Salary](
	[SalaryId] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeId] [int] NULL,
	[GrossAmount] [decimal](18, 2) NULL,
	[Deduction] [decimal](18, 2) NULL,
	[NetAmount] [decimal](18, 2) NULL,
	[SalaryDate] [date] NULL,
PRIMARY KEY CLUSTERED 
(
	[SalaryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[Employee] ON 
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (1, N'Harish', N'Salve', CAST(N'1984-09-02' AS Date), N'Employee', 1, CAST(N'2017-04-23' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (2, N'Sekhar', N'Joshi', CAST(N'1992-03-28' AS Date), N'Employee', 1, CAST(N'2017-08-19' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (3, N'Om', N'Shinde', CAST(N'1984-05-08' AS Date), N'Manager', 1, CAST(N'2019-04-12' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (4, N'Paritosh', N'Singh', CAST(N'1988-07-06' AS Date), N'Employee', 2, CAST(N'2017-10-09' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (5, N'Nirmal', N'Seth', CAST(N'1989-02-12' AS Date), N'Employee', 2, CAST(N'2017-08-10' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (6, N'Somnath', N'Dangle', CAST(N'1990-06-12' AS Date), N'Manager', 2, CAST(N'2019-04-02' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (7, N'Rajender', N'Sean', CAST(N'1995-11-02' AS Date), N'Employee', 3, CAST(N'2012-03-25' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (8, N'Santosh', N'Maurya', CAST(N'1982-12-06' AS Date), N'Employee', 3, CAST(N'2014-09-26' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (9, N'Kiran', N'Kharge', CAST(N'1988-08-22' AS Date), N'Manager', 3, CAST(N'2018-04-17' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (10, N'Suraj', N'Singh', CAST(N'1989-02-22' AS Date), N'Employee', 4, CAST(N'2017-04-12' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (11, N'Arjun', N'Kol', CAST(N'1985-07-09' AS Date), N'Employee', 4, CAST(N'2016-07-12' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (12, N'Akhil', N'Pawar', CAST(N'1980-09-11' AS Date), N'Manager', 4, CAST(N'2017-10-12' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (13, N'Akhilesh', N'Rawat', CAST(N'1997-03-26' AS Date), N'Employee', 5, CAST(N'2016-09-12' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (14, N'Rahul', N'Gaikwad', CAST(N'1993-11-12' AS Date), N'Employee', 5, CAST(N'2017-04-25' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (15, N'Rakesh', N'Chavanke', CAST(N'1984-02-02' AS Date), N'Manager', 5, CAST(N'2018-06-12' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (16, N'Ashok', N'Pawar', CAST(N'1996-09-21' AS Date), N'Employee', 6, CAST(N'2019-07-15' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (17, N'Vijay', N'Chavan', CAST(N'1991-10-22' AS Date), N'Employee', 6, CAST(N'2017-04-28' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (18, N'Nilesh', N'Patil', CAST(N'1986-09-23' AS Date), N'Manager', 6, CAST(N'2017-04-12' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (19, N'Raksh', N'Mahajan', CAST(N'1994-09-07' AS Date), N'Employee', 7, CAST(N'2019-08-09' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (20, N'Saurabh', N'Kumar', CAST(N'1998-07-15' AS Date), N'Employee', 7, CAST(N'2015-11-22' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (21, N'Pankaj', N'Shinde', CAST(N'1998-02-27' AS Date), N'Manager', 7, CAST(N'2010-04-12' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (22, N'Shivam', N'Ojha', CAST(N'1999-07-09' AS Date), N'Employee', 8, CAST(N'2019-04-12' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (23, N'Naman', N'Kamat', CAST(N'1988-06-14' AS Date), N'Employee', 8, CAST(N'2019-11-10' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (24, N'Sai', N'Selke', CAST(N'1985-01-31' AS Date), N'Manager', 8, CAST(N'2019-07-22' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (25, N'Raghav', N'Chaudhary', CAST(N'2000-12-08' AS Date), N'Employee', 9, CAST(N'2017-04-12' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (26, N'Vivek', N'Gupta', CAST(N'1998-10-12' AS Date), N'Employee', 9, CAST(N'2017-04-12' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (27, N'Sohan', N'Ugale', CAST(N'1982-07-16' AS Date), N'Manager', 9, CAST(N'2017-04-12' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (28, N'Pravin', N'Mandal', CAST(N'1981-03-30' AS Date), N'Employee', 10, CAST(N'2021-11-19' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (29, N'Suresh', N'Mahoto', CAST(N'1996-11-08' AS Date), N'Employee', 10, CAST(N'2022-06-10' AS Date))
GO
INSERT [dbo].[Employee] ([EmployeeId], [Firstname], [Lastname], [DOB], [Role], [PharmacyId], [DateofJoining]) VALUES (30, N'Rohit', N'Nagre', CAST(N'1987-06-12' AS Date), N'Manager', 10, CAST(N'2021-09-20' AS Date))
GO
SET IDENTITY_INSERT [dbo].[Employee] OFF
GO
SET IDENTITY_INSERT [dbo].[PaymentCode] ON 
GO
INSERT [dbo].[PaymentCode] ([PaymentCodeId], [PaymentCode], [DeductionRate]) VALUES (1, N'BASICPAY', CAST(0.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[PaymentCode] ([PaymentCodeId], [PaymentCode], [DeductionRate]) VALUES (2, N'PF', CAST(5.10 AS Decimal(18, 2)))
GO
INSERT [dbo].[PaymentCode] ([PaymentCodeId], [PaymentCode], [DeductionRate]) VALUES (3, N'PENSION', CAST(8.20 AS Decimal(18, 2)))
GO
SET IDENTITY_INSERT [dbo].[PaymentCode] OFF
GO
SET IDENTITY_INSERT [dbo].[Payslip] ON 
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (1, 1, 1)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (2, 2, 1)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (3, 3, 1)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (4, 1, 2)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (5, 2, 2)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (6, 3, 2)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (7, 1, 3)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (8, 2, 3)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (9, 3, 3)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (10, 1, 4)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (11, 2, 4)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (12, 3, 4)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (13, 1, 5)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (14, 2, 5)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (15, 3, 5)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (16, 1, 6)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (17, 2, 6)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (18, 3, 6)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (19, 1, 7)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (20, 2, 7)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (21, 3, 7)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (22, 1, 8)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (23, 2, 8)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (24, 3, 8)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (25, 1, 9)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (26, 2, 9)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (27, 3, 9)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (28, 1, 10)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (29, 2, 10)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (30, 3, 10)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (31, 1, 11)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (32, 2, 11)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (33, 3, 11)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (34, 1, 12)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (35, 2, 12)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (36, 3, 12)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (37, 1, 13)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (38, 2, 13)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (39, 3, 13)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (40, 1, 14)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (41, 2, 14)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (42, 3, 14)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (43, 1, 15)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (44, 2, 15)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (45, 3, 15)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (46, 1, 16)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (47, 2, 16)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (48, 3, 16)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (49, 1, 17)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (50, 2, 17)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (51, 3, 17)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (52, 1, 18)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (53, 2, 18)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (54, 3, 18)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (55, 1, 19)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (56, 2, 19)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (57, 3, 19)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (58, 1, 20)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (59, 2, 20)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (60, 3, 20)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (61, 1, 21)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (62, 2, 21)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (63, 3, 21)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (64, 1, 22)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (65, 2, 22)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (66, 3, 22)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (67, 1, 23)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (68, 2, 23)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (69, 3, 23)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (70, 1, 24)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (71, 2, 24)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (72, 3, 24)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (73, 1, 25)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (74, 2, 25)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (75, 3, 25)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (76, 1, 26)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (77, 2, 26)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (78, 3, 26)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (79, 1, 27)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (80, 2, 27)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (81, 3, 27)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (82, 1, 28)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (83, 2, 28)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (84, 3, 28)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (85, 1, 29)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (86, 2, 29)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (87, 3, 29)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (88, 1, 30)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (89, 2, 30)
GO
INSERT [dbo].[Payslip] ([PayslipId], [PaymentCodeId], [EmployeeId]) VALUES (90, 3, 30)
GO
SET IDENTITY_INSERT [dbo].[Payslip] OFF
GO
SET IDENTITY_INSERT [dbo].[Pharmacy] ON 
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (1, N'CVS Pharmacy', N'p0001', N'Nashik', N'22/01/2017')
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (2, N'Walgreens', N'p0002', N'Kolkata', N'24/05/2017')
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (3, N'Rite Aid', N'p0003', N'Mumbai', N'12/01/2012')
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (4, N'Omnicare', N'p0004', N'Pune', N'02/09/2015')
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (5, N'Prescription Hope', N'p0005', N'Delhi', N'26/07/2016')
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (6, N'Express Scripts', N'p0006', N'Bangalore ', N'25/08/2016')
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (7, N'People Choice Pharmacy', N'p0007', N'Amhedabad', N'02/09/2009')
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (8, N'Health Mart', N'p0008', N'Vanaras', N'29/10/2018')
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (9, N'Cardinal Health', N'p0009', N'Patna', N'16/11/2011')
GO
INSERT [dbo].[Pharmacy] ([PharmacyId], [Name], [Code], [City], [CreatedDate]) VALUES (10, N'Goodlife', N'p0010', N'Ranchi', N'05/07/2020')
GO
SET IDENTITY_INSERT [dbo].[Pharmacy] OFF
GO
SET IDENTITY_INSERT [dbo].[Salary] ON 
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (1, 1, CAST(18200.00 AS Decimal(18, 2)), CAST(2420.60 AS Decimal(18, 2)), CAST(15779.40 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (2, 2, CAST(17300.00 AS Decimal(18, 2)), CAST(2300.90 AS Decimal(18, 2)), CAST(14999.10 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (3, 3, CAST(65200.00 AS Decimal(18, 2)), CAST(8671.60 AS Decimal(18, 2)), CAST(56528.40 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (4, 4, CAST(18100.00 AS Decimal(18, 2)), CAST(2407.30 AS Decimal(18, 2)), CAST(15692.70 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (5, 5, CAST(16500.00 AS Decimal(18, 2)), CAST(2194.50 AS Decimal(18, 2)), CAST(14305.50 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (6, 6, CAST(68250.00 AS Decimal(18, 2)), CAST(9077.25 AS Decimal(18, 2)), CAST(59172.75 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (7, 7, CAST(19160.00 AS Decimal(18, 2)), CAST(2548.28 AS Decimal(18, 2)), CAST(16611.72 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (8, 8, CAST(12050.00 AS Decimal(18, 2)), CAST(1602.65 AS Decimal(18, 2)), CAST(10447.35 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (9, 9, CAST(70200.00 AS Decimal(18, 2)), CAST(9336.60 AS Decimal(18, 2)), CAST(60863.40 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (10, 10, CAST(15500.00 AS Decimal(18, 2)), CAST(2061.50 AS Decimal(18, 2)), CAST(13438.50 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (11, 11, CAST(21210.00 AS Decimal(18, 2)), CAST(2820.93 AS Decimal(18, 2)), CAST(18389.07 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (12, 12, CAST(55207.00 AS Decimal(18, 2)), CAST(7342.53 AS Decimal(18, 2)), CAST(47864.47 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (13, 13, CAST(9200.00 AS Decimal(18, 2)), CAST(1223.60 AS Decimal(18, 2)), CAST(7976.40 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (14, 14, CAST(15530.00 AS Decimal(18, 2)), CAST(2065.49 AS Decimal(18, 2)), CAST(13464.51 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (15, 15, CAST(58200.00 AS Decimal(18, 2)), CAST(7740.60 AS Decimal(18, 2)), CAST(50459.40 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (16, 16, CAST(17800.00 AS Decimal(18, 2)), CAST(2367.40 AS Decimal(18, 2)), CAST(15432.60 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (17, 17, CAST(11600.00 AS Decimal(18, 2)), CAST(1542.80 AS Decimal(18, 2)), CAST(10057.20 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (18, 18, CAST(65280.00 AS Decimal(18, 2)), CAST(8682.24 AS Decimal(18, 2)), CAST(56597.76 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (19, 19, CAST(22200.00 AS Decimal(18, 2)), CAST(2952.60 AS Decimal(18, 2)), CAST(19247.40 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (20, 20, CAST(19400.00 AS Decimal(18, 2)), CAST(2580.20 AS Decimal(18, 2)), CAST(16819.80 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (21, 21, CAST(85600.00 AS Decimal(18, 2)), CAST(11384.80 AS Decimal(18, 2)), CAST(74215.20 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (22, 22, CAST(14200.00 AS Decimal(18, 2)), CAST(1888.60 AS Decimal(18, 2)), CAST(12311.40 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (23, 23, CAST(27200.00 AS Decimal(18, 2)), CAST(3617.60 AS Decimal(18, 2)), CAST(23582.40 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (24, 24, CAST(25400.00 AS Decimal(18, 2)), CAST(3378.20 AS Decimal(18, 2)), CAST(22021.80 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (25, 25, CAST(35200.00 AS Decimal(18, 2)), CAST(4681.60 AS Decimal(18, 2)), CAST(30518.40 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (26, 26, CAST(22600.00 AS Decimal(18, 2)), CAST(3005.80 AS Decimal(18, 2)), CAST(19594.20 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (27, 27, CAST(67500.00 AS Decimal(18, 2)), CAST(8977.50 AS Decimal(18, 2)), CAST(58522.50 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (28, 28, CAST(21240.00 AS Decimal(18, 2)), CAST(2824.92 AS Decimal(18, 2)), CAST(18415.08 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (29, 29, CAST(23200.00 AS Decimal(18, 2)), CAST(3085.60 AS Decimal(18, 2)), CAST(20114.40 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
INSERT [dbo].[Salary] ([SalaryId], [EmployeeId], [GrossAmount], [Deduction], [NetAmount], [SalaryDate]) VALUES (30, 30, CAST(79380.00 AS Decimal(18, 2)), CAST(10557.54 AS Decimal(18, 2)), CAST(68822.46 AS Decimal(18, 2)), CAST(N'2023-09-07' AS Date))
GO
SET IDENTITY_INSERT [dbo].[Salary] OFF
GO
ALTER TABLE [dbo].[Employee]  WITH CHECK ADD FOREIGN KEY([PharmacyId])
REFERENCES [dbo].[Pharmacy] ([PharmacyId])
GO
ALTER TABLE [dbo].[Payslip]  WITH CHECK ADD FOREIGN KEY([EmployeeId])
REFERENCES [dbo].[Employee] ([EmployeeId])
GO
ALTER TABLE [dbo].[Payslip]  WITH CHECK ADD FOREIGN KEY([PaymentCodeId])
REFERENCES [dbo].[PaymentCode] ([PaymentCodeId])
GO
ALTER TABLE [dbo].[Salary]  WITH CHECK ADD FOREIGN KEY([EmployeeId])
REFERENCES [dbo].[Employee] ([EmployeeId])
GO
/****** Object:  StoredProcedure [dbo].[EmployeeDetails]    Script Date: 9/8/2023 12:24:14 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE	PROCEDURE	[dbo].[EmployeeDetails]
@Case INT 
AS
BEGIN
  IF @Case=1 
   BEGIN

		SELECT Salary.SalaryId,
				Salary.EmployeeId,
				Salary.GrossAmount,
				Salary.Deduction,
				Salary.NetAmount,
				Salary.SalaryDate
		FROM	Salary
	   

   END
   IF @Case=2

   BEGIN

		SELECT Pharmacy.[Name],
		CONCAT(Employee.Firstname, ' ', Employee.Lastname) AS FullName,
		DATEDIFF(DAY, Employee.DOB, GETDATE()) AS AgeInDayofBirth, 
		Employee.[Role]
		FROM	Pharmacy
	    INNER JOIN 
		Employee  ON Employee.PharmacyId = Pharmacy.PharmacyId;
	END

----Get the total deduction of all users having the role 'Manager'. (Username, TotalDeduction)
IF @Case=3

   BEGIN

		SELECT	CONCAT(EMP.Firstname, ' ', EMP.Lastname) AS Username,
				S.Deduction												AS TotalDeduction
		FROM	Salary	AS	S
		INNER	JOIN	Employee	AS	EMP
		ON		S.EmployeeId=EMP.EmployeeId
		WHERE	EMP.ROLE='MANAGER'

   END
 END
GO
USE [master]
GO
ALTER DATABASE [PharmacyManagment] SET  READ_WRITE 
GO
