SET NOCOUNT ON
--Assignment no-2

 DROP TABLE IF EXISTS Hospital2,Patientdetail2,Appointment2;

DROP TABLE Hospital2
DROP TABLE Patientdetail2
DROP TABLE  Appointment2


--Create Dataase for Hospital

CREATE TABLE Hospital2
(
	HospitalId INT NOT NULL,
    HospitalName VARCHAR(50) NOT NULL,
	HospitalAddress  VARCHAR(70) NOT NULL,
	City  VARCHAR(50)  NOT NULL,
	ZipCode INT NOT NULL,
	Ambulancefacility BIT NOT NULL,
	ContactNumber  VARCHAR(50)  NOT NULL,
	NumberofDoctors INT NOT NULL,
 );

	 INSERT INTO Hospital2 VALUES(7720, 'Appolo Hospital', 'Panchvati', 'Nashik', 422003, 1, '022-21242124',32),
	                              (7725, 'Ashoka Medicover Hospital', 'Indira Nagar', 'Nashik', 422009, 1, '022-21242154',45),
								  (3321, 'Six Sigma Hospital', 'Mahatma Nagar', 'Nashik', 422001, 1, '022-21242150', 10),
								  (4423, 'Sahyadri Hospital', 'Bhabha Nagar', 'Nashik', 422001, 1, '022-21242655',22),
								  (1025, 'Wockhardt Hospital', 'Wadala', 'Nashik', 422006, 1, '022-21243512',6),
								  (1025, 'Vakratund Hospital Pvt. Ltd.', 'Pathardi', 'Nashik', 422010, 1, '022-21242144',4)

  --DROP TABLE Hospital
  SELECT * FROM Hospital2

  --Create Dataase for Patient

  CREATE TABLE Patientdetail2
(
	PatientNo INT NOT NULL,
    Patientname VARCHAR(50) NOT NULL,
   Age INT NOT NULL,
   Gender VARCHAR(50) NOT NULL,
   PhoneNo  VARCHAR(50)  NOT NULL,
   PatientAddress VARCHAR(100) NOT NULL,
   AdmitDepartment VARCHAR(50) NOT NULL, 
   AdmitDate VARCHAR(25) NOT NULL,
   DischargeDate VARCHAR(25) NOT NULL
);

INSERT INTO Patientdetail2 VALUES (1, 'Shubham Gorade', 21, 'Male', '9428653217', 'Snnar', 'Cardiology', '15/05/2022', '17/05/2022'),
                                  (2, 'Sahil Shaikh', 21, 'Male', '2546412535', 'Nashik', 'Orthopedics', '17/02/2023', '23/02/2023'),
                                  (3, 'Ritesh Gadakh', 21, 'Male', '9865241035', 'Nashik', 'Radiology', '21/01/2023', '30/01/2023'),
                                  (4, 'Amol Kalaskar', 21, 'Male', '7754321565', 'Nashik', 'Neurology', '29/03/2023', '01/04/2023'),
                                  (5, 'Rahul Jadhav', 21, 'Male', '6824065032', 'Nashik', 'Orthopedics', '13/03/2023', '23/03/2023')

	   SELECT * FROM Patientdetail2;

	    --Create Dataase for Appointment

     CREATE TABLE Appointment2
	 (
		AppointmentNo INT NOT NULL,
		PatientName VARCHAR(50) NOT NULL,
		DepartmentName  VARCHAR(50) NOT NULL,
		AppointedDoctorName  VARCHAR(50) NOT NULL,
		StartDate  VARCHAR(50) NOT NULL,
		EndDate  VARCHAR(50) NOT NULL,
		Fees FLOAT 	NOT NULL,	
		PatientNo INT NOT NULL,
	);


	 INSERT INTO Appointment2 VALUES(1224, 'Shubham Gorade', 'Cardiology', 'Dr. SheetalKumar Hiran','24/06/2023', '24/06/2023', 500, 110652),
								    (3417, 'Sahil Shaikh',	'Orthopedics', 'Dr. Prashant Somani',�'22/03/2023', '22/03/2023',	200, 110653),
								    (6241,	'Ritesh Gadakh', 'Radiology',	'Dr. Ajaya Nand Jha',	'29/07/2023',	'29/07/2023',	650, 110654),
                                    (2257, 'Amol Kalaskar', 'Neurology', 'Dr. Suresh Josh', '13/02/2023',	'13/02/2023',	400, 110655),
                                    (3512,	'Rohan Singh',	'Orthopedics',	'Dr. Prashant Somani',�	'17/03/2023',	'17/03/2023',	200, 110656),
                                    (6544,	'Rahul Jadhav',	'Neurology',	'Dr. Suresh Josh',	'19/03/2023',	'19/03/2023',	400, 110657)

   SELECT * FROM Appointment2
   



    
--//variables
DECLARE @name VARCHAR(10) = 'kailash'
PRINT @name


DECLARE @Today DATETIME 
SET @Today = GETDATE()
PRINT @Today

DECLARE @Status BIT 
SELECT @Status = 1
PRINT @Status

DECLARE @NO INT = 100
PRINT @NO

DECLARE @Average DECIMAL(18,3) = '3546258.36989';
PRINT @Average

DECLARE @date DATETIME 
SET @date = GETDATE()
PRINT @date